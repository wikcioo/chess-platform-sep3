package via.sep3.DatabaseAccessServer.domain.enums;

public enum GameType {
  AI, FRIEND, RANDOM
}
