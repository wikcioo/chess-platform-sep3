package via.sep3.DatabaseAccessServer.domain.enums;

public enum GameOutcome {
    WHITE, BLACK, DRAW
}
