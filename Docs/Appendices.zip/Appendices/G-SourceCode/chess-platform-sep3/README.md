# chess-platform-sep3
A distributed chess platform project for SEP3
