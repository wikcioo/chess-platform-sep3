window.PlaySound = function(sound) {
    document.getElementById(sound).play();
}