namespace Domain.DTOs.Chat;

public class RequestMessageDto
{
    public ulong GameRoom { get; init; }
}