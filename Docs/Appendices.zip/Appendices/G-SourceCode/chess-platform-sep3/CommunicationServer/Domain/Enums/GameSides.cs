﻿namespace Domain.Enums;

public enum GameSides
{
    White = 0,
    Black = 1,
    Random = 2
}