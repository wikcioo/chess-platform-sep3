namespace Domain.Enums;

public enum PositionType
{
    Fen,
    StartPos
}