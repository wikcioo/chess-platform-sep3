namespace Domain.Enums;

public enum AuthUserEvents
{
    NewGameOffer = 0
}