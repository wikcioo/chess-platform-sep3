﻿namespace Domain.Enums;

public enum GameOutcome
{
    White = 0,
    Black = 1, 
    Draw = 2
}