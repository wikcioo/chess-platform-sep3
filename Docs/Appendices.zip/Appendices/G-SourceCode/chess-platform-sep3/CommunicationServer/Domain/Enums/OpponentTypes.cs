﻿namespace Domain.Enums;

public enum OpponentTypes
{
    Ai = 0,
    Friend = 1,
    Random = 2
}